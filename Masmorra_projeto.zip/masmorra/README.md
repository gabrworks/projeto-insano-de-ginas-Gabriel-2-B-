# Masmorra

Jogo de masmorra em console feito para o projeto final de Estrutura de Dados com Java.

## Compilar e executar (Java 11+)
```
mkdir out
javac -encoding UTF-8 -d out $(find src -name '*.java')
java -Dfile.encoding=UTF-8 -cp out jogo.Main
```

## Onde cada estrutura é usada
| Estrutura | Classe | Uso no jogo |
|---|---|---|
| Array | `Mapa`, `CatalogoItens` | mapa 5x5 e catálogo ordenado de itens |
| Lista encadeada | `ListaEncadeada` | mochila do jogador e resultado dos percursos |
| Pilha | `Pilha` | desfazer movimento |
| Fila | `Fila` | monstros na ordem de aparição |
| Busca binária/linear | `Busca` | achar item no catálogo e benchmark |
| ABB | `ArvoreBinariaBusca` | ranking de jogadores por nome |
