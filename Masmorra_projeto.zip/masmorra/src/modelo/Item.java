package modelo;

/** Item do jogo. A ordem natural é pelo id (usada na busca binária do catálogo). */
public class Item implements Comparable<Item> {
    private final int id;
    private final String nome;
    private final int valor;

    /**
     * @param id    identificador único
     * @param nome  nome do item
     * @param valor pontos que o item vale
     */
    public Item(int id, String nome, int valor) {
        this.id = id;
        this.nome = nome;
        this.valor = valor;
    }

    /** @return id do item */
    public int getId() { return id; }

    /** @return nome do item */
    public String getNome() { return nome; }

    /** @return pontos do item */
    public int getValor() { return valor; }

    @Override
    public int compareTo(Item outro) { return Integer.compare(id, outro.id); }

    @Override
    public boolean equals(Object o) { return o instanceof Item && ((Item) o).id == id; }

    @Override
    public int hashCode() { return id; }

    @Override
    public String toString() { return "#" + id + " " + nome + " (" + valor + " pts)"; }
}
