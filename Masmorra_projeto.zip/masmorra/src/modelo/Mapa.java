package modelo;

import excecoes.EntradaInvalidaException;

/**
 * Mapa da masmorra guardado em uma matriz (array bidimensional) de char.
 * '.' vazio, 'I' item, 'M' monstro, 'T' tesouro.
 */
public class Mapa {
    private static final String[] LAYOUT = {
        ". . I . M",
        ". M . I .",
        "I . . M .",
        ". I M . .",
        "M . . . T"
    };
    private final char[][] grade;

    /** Cria o mapa fixo 5x5. */
    public Mapa() {
        grade = new char[LAYOUT.length][];
        for (int i = 0; i < LAYOUT.length; i++) {
            grade[i] = LAYOUT[i].replace(" ", "").toCharArray();
        }
    }

    /** @return número de linhas */
    public int linhas() { return grade.length; }

    /** @return número de colunas */
    public int colunas() { return grade[0].length; }

    /**
     * @param l linha
     * @param c coluna
     * @return símbolo da célula
     * @throws EntradaInvalidaException se a posição estiver fora do mapa
     */
    public char get(int l, int c) {
        if (l < 0 || l >= linhas() || c < 0 || c >= colunas())
            throw new EntradaInvalidaException("Você bateu na parede!");
        return grade[l][c];
    }

    /** Esvazia uma célula (item pego ou monstro derrotado). */
    public void limpar(int l, int c) { grade[l][c] = '.'; }

    /**
     * Desenha o mapa em texto.
     *
     * @param jl linha do jogador
     * @param jc coluna do jogador
     * @return texto do mapa com '@' na posição do jogador
     */
    public String desenhar(int jl, int jc) {
        StringBuilder sb = new StringBuilder();
        for (int l = 0; l < linhas(); l++) {
            for (int c = 0; c < colunas(); c++) {
                sb.append(l == jl && c == jc ? '@' : grade[l][c]).append(' ');
            }
            sb.append('\n');
        }
        return sb.toString();
    }
}
