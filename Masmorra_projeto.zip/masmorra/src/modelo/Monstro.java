package modelo;

/** Monstro que aparece na masmorra. */
public class Monstro {
    private final String nome;
    private final int dano;
    private final int pontos;

    /**
     * @param nome   nome do monstro
     * @param dano   vida que o jogador perde ao encontrá-lo
     * @param pontos pontos ganhos ao derrotá-lo
     */
    public Monstro(String nome, int dano, int pontos) {
        this.nome = nome;
        this.dano = dano;
        this.pontos = pontos;
    }

    /** @return nome */
    public String getNome() { return nome; }

    /** @return dano causado */
    public int getDano() { return dano; }

    /** @return pontos concedidos */
    public int getPontos() { return pontos; }
}
