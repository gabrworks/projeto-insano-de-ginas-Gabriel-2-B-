package modelo;

/** Jogador do ranking. A ordem natural é pelo nome (ordem alfabética). */
public class Jogador implements Comparable<Jogador> {
    private final String nome;
    private final int pontos;

    /**
     * @param nome   nome do jogador
     * @param pontos pontuação final
     */
    public Jogador(String nome, int pontos) {
        this.nome = nome;
        this.pontos = pontos;
    }

    /** @return nome */
    public String getNome() { return nome; }

    /** @return pontuação */
    public int getPontos() { return pontos; }

    @Override
    public int compareTo(Jogador outro) { return nome.compareToIgnoreCase(outro.nome); }

    @Override
    public String toString() { return nome + " - " + pontos + " pts"; }
}
