package jogo;

import busca.CatalogoItens;
import busca.ComparadorBusca;
import busca.ResultadoBusca;
import estruturas.ArvoreBinariaBusca;
import excecoes.EntradaInvalidaException;
import excecoes.EstruturaVaziaException;
import modelo.Item;
import modelo.Jogador;
import java.util.Scanner;

/** Interface de console: menu principal, partida, ranking e demonstrações de busca. */
public class Menu {
    private final Scanner entrada = new Scanner(System.in);
    private final CatalogoItens catalogo = new CatalogoItens();
    private final ArvoreBinariaBusca<Jogador> ranking = new ArvoreBinariaBusca<>();

    /** Monta o catálogo (fora de ordem de propósito) e o ranking inicial. */
    public Menu() {
        int[] ids = {120, 30, 200, 80, 10, 150, 60, 190, 20, 110, 90, 170, 40, 140, 70, 180, 50, 130, 100, 160};
        String[] nomes = {"Espada", "Escudo", "Coroa", "Poção", "Adaga", "Arco", "Mapa", "Anel", "Tocha", "Elmo",
                "Botas", "Cajado", "Chave", "Amuleto", "Corda", "Livro", "Capa", "Luva", "Moeda", "Gema"};
        for (int i = 0; i < ids.length; i++) {
            catalogo.inserir(new Item(ids[i], nomes[i], (i % 5 + 1) * 5));
        }
        ranking.inserir(new Jogador("Marcos", 80));
        ranking.inserir(new Jogador("Ana", 120));
        ranking.inserir(new Jogador("Zeca", 45));
        ranking.inserir(new Jogador("Carla", 95));
        ranking.inserir(new Jogador("Bruno", 60));
    }

    /** Laço do menu principal. */
    public void executar() {
        boolean rodando = true;
        while (rodando) {
            System.out.println("\n=== MASMORRA ===");
            System.out.println("1 - Jogar");
            System.out.println("2 - Ver ranking (percursos da árvore)");
            System.out.println("3 - Buscar jogador no ranking");
            System.out.println("4 - Catálogo de itens (busca linear x binária)");
            System.out.println("5 - Comparar desempenho das buscas");
            System.out.println("0 - Sair");
            System.out.print("Opção: ");
            try {
                String op = entrada.nextLine().trim();
                switch (op) {
                    case "1": jogar(); break;
                    case "2": mostrarRanking(); break;
                    case "3": buscarJogador(); break;
                    case "4": mostrarCatalogo(); break;
                    case "5": System.out.println(ComparadorBusca.executar(new int[]{1000, 10000, 100000, 1000000}, 200)); break;
                    case "0": rodando = false; break;
                    default: throw new EntradaInvalidaException("Opção inválida: '" + op + "'");
                }
            } catch (EntradaInvalidaException e) {
                System.out.println("Erro: " + e.getMessage());
            } catch (java.util.NoSuchElementException e) {
                rodando = false; // fim da entrada
            }
        }
        System.out.println("Até a próxima!");
    }

    private void jogar() {
        Jogo jogo = new Jogo(catalogo);
        System.out.println("Comandos: w/a/s/d = andar, u = desfazer, m = mochila, b = buscar na mochila, l = largar item, q = desistir");
        while (!jogo.terminou()) {
            System.out.println();
            System.out.print(jogo.desenhar());
            System.out.println("Vida: " + jogo.getVida() + " | Pontos: " + jogo.getPontos()
                    + " | Monstros na fila: " + jogo.monstrosRestantes());
            System.out.print("> ");
            String cmd = entrada.nextLine().trim().toLowerCase();
            try {
                if (cmd.equals("q")) break;
                else if (cmd.equals("u")) System.out.println(jogo.desfazer());
                else if (cmd.equals("m")) listarMochila(jogo);
                else if (cmd.equals("b")) buscarNaMochila(jogo);
                else if (cmd.equals("l")) largarItem(jogo);
                else System.out.println(jogo.mover(cmd));
            } catch (EstruturaVaziaException | EntradaInvalidaException e) {
                System.out.println("Aviso: " + e.getMessage());
            }
        }
        System.out.println(jogo.venceu() ? "\nVocê VENCEU!" : "\nFim de jogo.");
        System.out.println("Pontuação final: " + jogo.getPontos());
        System.out.print("Seu nome para o ranking: ");
        String nome = entrada.nextLine().trim();
        if (nome.isEmpty()) throw new EntradaInvalidaException("Nome vazio, pontuação não registrada.");
        if (ranking.inserir(new Jogador(nome, jogo.getPontos()))) System.out.println("Registrado no ranking!");
        else System.out.println("Esse nome já está no ranking.");
    }

    private void listarMochila(Jogo jogo) {
        if (jogo.getMochila().estaVazia()) { System.out.println("Mochila vazia."); return; }
        System.out.println("Mochila (" + jogo.getMochila().tamanho() + " itens):");
        for (Item i : jogo.getMochila()) System.out.println("  " + i);
    }

    private void buscarNaMochila(Jogo jogo) {
        System.out.print("Id do item: ");
        int id = lerInteiro();
        boolean achou = jogo.getMochila().buscar(new Item(id, "", 0));
        System.out.println(achou ? "Você tem esse item." : "Você não tem esse item.");
    }

    private void largarItem(Jogo jogo) {
        System.out.print("Id do item para largar: ");
        int id = lerInteiro();
        boolean ok = jogo.getMochila().remover(new Item(id, "", 0)); // lança exceção se vazia
        System.out.println(ok ? "Item largado." : "Você não tem esse item.");
    }

    private void mostrarRanking() {
        if (ranking.estaVazia()) { System.out.println("Ranking vazio."); return; }
        System.out.println("Jogadores: " + ranking.tamanho() + " | Altura da árvore: " + ranking.altura());
        System.out.println("\nEM-ORDEM (lista em ordem alfabética):");
        for (Jogador j : ranking.emOrdem()) System.out.println("  " + j);
        System.out.println("\nPRÉ-ORDEM (raiz primeiro: mostra a forma da árvore / serve para copiá-la):");
        for (Jogador j : ranking.preOrdem()) System.out.println("  " + j);
        System.out.println("\nPÓS-ORDEM (filhos antes do pai: usada aqui para somar os pontos de todos):");
        int soma = 0;
        for (Jogador j : ranking.posOrdem()) { System.out.println("  " + j); soma += j.getPontos(); }
        System.out.println("  Soma total de pontos: " + soma);
    }

    private void buscarJogador() {
        System.out.print("Nome: ");
        String nome = entrada.nextLine().trim();
        Jogador j = ranking.buscar(new Jogador(nome, 0));
        System.out.println(j == null ? "Jogador não encontrado." : "Encontrado: " + j);
    }

    private void mostrarCatalogo() {
        System.out.println("Catálogo ordenado por id (" + catalogo.tamanho() + " itens, array de capacidade "
                + catalogo.capacidade() + "):");
        for (int i = 0; i < catalogo.tamanho(); i++) System.out.println("  [" + i + "] " + catalogo.obter(i));
        System.out.print("Id para buscar: ");
        int id = lerInteiro();
        ResultadoBusca lin = catalogo.buscarLinear(id);
        ResultadoBusca bin = catalogo.buscarBinaria(id);
        System.out.println("Linear : posição " + lin.getIndice() + ", " + lin.getComparacoes() + " comparações");
        System.out.println("Binária: posição " + bin.getIndice() + ", " + bin.getComparacoes() + " comparações");
    }

    private int lerInteiro() {
        String texto = entrada.nextLine().trim();
        try {
            return Integer.parseInt(texto);
        } catch (NumberFormatException e) {
            throw new EntradaInvalidaException("'" + texto + "' não é um número.");
        }
    }
}
