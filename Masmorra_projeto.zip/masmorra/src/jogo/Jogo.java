package jogo;

import busca.CatalogoItens;
import busca.ResultadoBusca;
import estruturas.Fila;
import estruturas.ListaEncadeada;
import estruturas.Pilha;
import excecoes.EntradaInvalidaException;
import modelo.Item;
import modelo.Mapa;
import modelo.Monstro;
import java.util.Random; // só para sortear itens com semente fixa

/**
 * Regras e estado de uma partida. Não conversa com o usuário (isso é da classe Menu).
 * Estruturas usadas: Mapa (array 2D), Pilha (desfazer), Fila (monstros),
 * ListaEncadeada (mochila) e CatalogoItens (array ordenado + busca binária).
 */
public class Jogo {
    private final Mapa mapa = new Mapa();
    private final CatalogoItens catalogo;
    private final Pilha<int[]> historico = new Pilha<>();
    private final Fila<Monstro> monstros = new Fila<>();
    private final ListaEncadeada<Item> mochila = new ListaEncadeada<>();
    private final Random sorteio = new Random(7);
    private int linha = 0, coluna = 0, vida = 15, pontos = 0;
    private boolean venceu = false;

    /** @param catalogo catálogo de itens usado para sortear os itens encontrados */
    public Jogo(CatalogoItens catalogo) {
        this.catalogo = catalogo;
        monstros.enfileirar(new Monstro("Rato Gigante", 3, 10));
        monstros.enfileirar(new Monstro("Esqueleto", 4, 15));
        monstros.enfileirar(new Monstro("Goblin", 5, 20));
        monstros.enfileirar(new Monstro("Morcego", 2, 5));
        monstros.enfileirar(new Monstro("Ogro", 6, 30));
    }

    /**
     * Move o jogador e resolve o que existe na nova célula.
     *
     * @param comando w, a, s ou d
     * @return mensagem do que aconteceu
     * @throws EntradaInvalidaException se o comando for inválido ou bater na parede
     */
    public String mover(String comando) {
        int nl = linha, nc = coluna;
        switch (comando) {
            case "w": nl--; break;
            case "s": nl++; break;
            case "a": nc--; break;
            case "d": nc++; break;
            default: throw new EntradaInvalidaException("Comando inválido: '" + comando + "'");
        }
        char celula = mapa.get(nl, nc); // lança exceção se for parede
        historico.empilhar(new int[]{linha, coluna});
        linha = nl;
        coluna = nc;
        String msg = "Você andou.";
        if (celula == 'I') {
            // sorteia um id do catálogo e acha o item com BUSCA BINÁRIA
            int id = (sorteio.nextInt(catalogo.tamanho()) + 1) * 10;
            ResultadoBusca r = catalogo.buscarBinaria(id);
            Item item = catalogo.obter(r.getIndice());
            mochila.inserir(item);
            pontos += item.getValor();
            mapa.limpar(linha, coluna);
            msg = "Você achou " + item + " (busca binária: " + r.getComparacoes() + " comparações).";
        } else if (celula == 'M') {
            Monstro m = monstros.desenfileirar(); // próximo da fila
            vida -= m.getDano();
            pontos += m.getPontos();
            mapa.limpar(linha, coluna);
            msg = "Um " + m.getNome() + " apareceu! Você perdeu " + m.getDano()
                    + " de vida e ganhou " + m.getPontos() + " pts.";
        } else if (celula == 'T') {
            venceu = true;
            pontos += 100;
            msg = "TESOURO ENCONTRADO! +100 pts.";
        }
        return msg;
    }

    /**
     * Desfaz o último movimento (só a posição; itens e monstros já consumidos não voltam).
     *
     * @return mensagem
     * @throws excecoes.EstruturaVaziaException se não há movimento para desfazer
     */
    public String desfazer() {
        int[] anterior = historico.desempilhar();
        linha = anterior[0];
        coluna = anterior[1];
        return "Movimento desfeito.";
    }

    /** @return true se o jogo acabou (venceu ou morreu) */
    public boolean terminou() { return venceu || vida <= 0; }

    /** @return true se pegou o tesouro */
    public boolean venceu() { return venceu; }

    /** @return mapa em texto */
    public String desenhar() { return mapa.desenhar(linha, coluna); }

    /** @return vida atual */
    public int getVida() { return vida; }

    /** @return pontos atuais */
    public int getPontos() { return pontos; }

    /** @return mochila do jogador */
    public ListaEncadeada<Item> getMochila() { return mochila; }

    /** @return quantos monstros ainda estão na fila */
    public int monstrosRestantes() { return monstros.tamanho(); }

    /** @return quantos movimentos podem ser desfeitos */
    public int movimentosGuardados() { return historico.tamanho(); }
}
