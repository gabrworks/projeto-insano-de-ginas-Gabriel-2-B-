package jogo;

/** Ponto de entrada do jogo Masmorra. */
public class Main {
    /** @param args não utilizado */
    public static void main(String[] args) {
        new Menu().executar();
    }
}
