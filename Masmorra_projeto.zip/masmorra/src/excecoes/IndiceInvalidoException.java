package excecoes;

/** Lançada quando um índice fora dos limites é usado em uma estrutura. */
public class IndiceInvalidoException extends RuntimeException {
    /**
     * @param indice  índice informado
     * @param tamanho tamanho atual da estrutura
     */
    public IndiceInvalidoException(int indice, int tamanho) {
        super("Índice inválido: " + indice + " (tamanho = " + tamanho + ").");
    }
}
