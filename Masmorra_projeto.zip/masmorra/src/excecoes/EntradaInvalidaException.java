package excecoes;

/** Lançada quando o usuário digita um comando ou valor malformado. */
public class EntradaInvalidaException extends RuntimeException {
    /** @param mensagem descrição do problema */
    public EntradaInvalidaException(String mensagem) {
        super(mensagem);
    }
}
