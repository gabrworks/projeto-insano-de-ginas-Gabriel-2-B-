package excecoes;

/** Lançada ao tentar remover ou consultar um elemento de uma estrutura vazia. */
public class EstruturaVaziaException extends RuntimeException {
    /** @param estrutura nome da estrutura que está vazia */
    public EstruturaVaziaException(String estrutura) {
        super("A estrutura " + estrutura + " está vazia.");
    }
}
