package busca;

import modelo.Item;

/**
 * Catálogo de itens do jogo guardado em um array que é MANTIDO ORDENADO por id.
 * Cada inserção desloca os elementos maiores para a direita (como no insertion sort),
 * então a busca binária sempre pode ser usada. Quando o array enche, ele é
 * redimensionado manualmente (dobra de tamanho).
 */
public class CatalogoItens {
    private Item[] itens = new Item[4];
    private int quantidade;

    /**
     * Insere o item na posição correta para manter a ordem. Custo O(n) (deslocamento).
     *
     * @param item item a inserir
     */
    public void inserir(Item item) {
        if (quantidade == itens.length) redimensionar();
        int i = quantidade - 1;
        while (i >= 0 && itens[i].compareTo(item) > 0) {
            itens[i + 1] = itens[i];
            i--;
        }
        itens[i + 1] = item;
        quantidade++;
    }

    private void redimensionar() {
        Item[] novo = new Item[itens.length * 2];
        for (int i = 0; i < quantidade; i++) novo[i] = itens[i];
        itens = novo;
    }

    /** @param id id procurado @return resultado da busca binária (índice e comparações) */
    public ResultadoBusca buscarBinaria(int id) {
        return Busca.binaria(itens, quantidade, new Item(id, "", 0));
    }

    /** @param id id procurado @return resultado da busca linear (índice e comparações) */
    public ResultadoBusca buscarLinear(int id) {
        return Busca.linear(itens, quantidade, new Item(id, "", 0));
    }

    /** @param indice posição no array @return item da posição */
    public Item obter(int indice) { return itens[indice]; }

    /** @return quantidade de itens */
    public int tamanho() { return quantidade; }

    /** @return capacidade atual do array interno */
    public int capacidade() { return itens.length; }
}
