package busca;

/** Algoritmos de busca linear e binária sobre arrays. */
public class Busca {
    private Busca() { }

    /**
     * Busca linear. Melhor caso O(1), pior e médio O(n).
     *
     * @param v     array (não precisa estar ordenado)
     * @param tamanho quantidade de posições realmente usadas
     * @param chave valor procurado
     * @param <T>   tipo comparável
     * @return índice e comparações
     */
    public static <T extends Comparable<T>> ResultadoBusca linear(T[] v, int tamanho, T chave) {
        int comparacoes = 0;
        for (int i = 0; i < tamanho; i++) {
            comparacoes++;
            if (v[i].compareTo(chave) == 0) return new ResultadoBusca(i, comparacoes);
        }
        return new ResultadoBusca(-1, comparacoes);
    }

    /**
     * Busca binária iterativa. Exige array ORDENADO. Melhor caso O(1), pior e médio O(log n).
     *
     * @param v       array ordenado
     * @param tamanho quantidade de posições realmente usadas
     * @param chave   valor procurado
     * @param <T>     tipo comparável
     * @return índice e comparações
     */
    public static <T extends Comparable<T>> ResultadoBusca binaria(T[] v, int tamanho, T chave) {
        int comparacoes = 0;
        int ini = 0, fim = tamanho - 1;
        while (ini <= fim) {
            int meio = (ini + fim) / 2;
            comparacoes++;
            int cmp = v[meio].compareTo(chave);
            if (cmp == 0) return new ResultadoBusca(meio, comparacoes);
            if (cmp < 0) ini = meio + 1;
            else fim = meio - 1;
        }
        return new ResultadoBusca(-1, comparacoes);
    }

    /**
     * Busca binária recursiva (mesma ideia da iterativa).
     *
     * @param v       array ordenado
     * @param ini     início do intervalo
     * @param fim     fim do intervalo
     * @param chave   valor procurado
     * @param <T>     tipo comparável
     * @return índice ou -1
     */
    public static <T extends Comparable<T>> int binariaRecursiva(T[] v, int ini, int fim, T chave) {
        if (ini > fim) return -1;
        int meio = (ini + fim) / 2;
        int cmp = v[meio].compareTo(chave);
        if (cmp == 0) return meio;
        if (cmp < 0) return binariaRecursiva(v, meio + 1, fim, chave);
        return binariaRecursiva(v, ini, meio - 1, chave);
    }
}
