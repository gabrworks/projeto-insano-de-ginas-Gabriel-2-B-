package busca;

/** Resultado de uma busca: posição encontrada e quantidade de comparações. */
public class ResultadoBusca {
    private final int indice;
    private final int comparacoes;

    /**
     * @param indice      posição encontrada ou -1
     * @param comparacoes número de comparações feitas
     */
    public ResultadoBusca(int indice, int comparacoes) {
        this.indice = indice;
        this.comparacoes = comparacoes;
    }

    /** @return posição ou -1 se não achou */
    public int getIndice() { return indice; }

    /** @return comparações realizadas */
    public int getComparacoes() { return comparacoes; }
}
