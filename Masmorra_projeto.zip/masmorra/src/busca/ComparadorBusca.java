package busca;

import java.util.Random; // java.util usado só para gerar números aleatórios da medição (T3)

/** Mede comparações e tempo da busca linear x binária para volumes crescentes. */
public class ComparadorBusca {
    private ComparadorBusca() { }

    /**
     * Roda a comparação e devolve o relatório em texto (uma linha por volume).
     *
     * @param volumes  tamanhos de array a testar
     * @param consultas quantidade de buscas por volume
     * @return tabela em texto
     */
    public static String executar(int[] volumes, int consultas) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s | %-22s | %-22s%n", "n", "LINEAR (comp / ms)", "BINARIA (comp / ms)"));
        for (int n : volumes) {
            // array já nasce ordenado: 0, 2, 4, ... (só pares, então chaves ímpares não existem)
            Integer[] v = new Integer[n];
            for (int i = 0; i < n; i++) v[i] = i * 2;
            Random r = new Random(1);
            Integer[] chaves = new Integer[consultas];
            for (int i = 0; i < consultas; i++) chaves[i] = r.nextInt(n * 2);

            long compLin = 0, compBin = 0;
            long t0 = System.nanoTime();
            for (Integer k : chaves) compLin += Busca.linear(v, n, k).getComparacoes();
            long t1 = System.nanoTime();
            for (Integer k : chaves) compBin += Busca.binaria(v, n, k).getComparacoes();
            long t2 = System.nanoTime();

            sb.append(String.format("%-10d | %10d / %-9.3f | %10d / %-9.3f%n", n,
                    compLin / consultas, (t1 - t0) / 1e6,
                    compBin / consultas, (t2 - t1) / 1e6));
        }
        return sb.toString();
    }
}
