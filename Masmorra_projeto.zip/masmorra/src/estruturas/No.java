package estruturas;

/**
 * Nó de uma estrutura encadeada simples (lista, pilha e fila).
 *
 * @param <T> tipo do valor guardado
 */
public class No<T> {
    private T valor;
    private No<T> proximo;

    /** @param valor valor guardado no nó */
    public No(T valor) {
        this.valor = valor;
    }

    /** @return valor do nó */
    public T getValor() { return valor; }

    /** @param valor novo valor */
    public void setValor(T valor) { this.valor = valor; }

    /** @return próximo nó (ou null) */
    public No<T> getProximo() { return proximo; }

    /** @param proximo novo próximo nó */
    public void setProximo(No<T> proximo) { this.proximo = proximo; }
}
