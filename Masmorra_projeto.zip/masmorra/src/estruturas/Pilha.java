package estruturas;

import excecoes.EstruturaVaziaException;

/**
 * Pilha (LIFO) encadeada. No jogo guarda o histórico de posições
 * para o comando "desfazer movimento".
 *
 * @param <T> tipo dos elementos
 */
public class Pilha<T> {
    private No<T> topo;
    private int tamanho;

    /** Empilha um valor. Custo O(1). @param valor elemento a empilhar */
    public void empilhar(T valor) {
        No<T> novo = new No<>(valor);
        novo.setProximo(topo);
        topo = novo;
        tamanho++;
    }

    /**
     * Desempilha o topo. Custo O(1).
     *
     * @return elemento removido
     * @throws EstruturaVaziaException se a pilha estiver vazia
     */
    public T desempilhar() {
        if (estaVazia()) throw new EstruturaVaziaException("Pilha");
        T valor = topo.getValor();
        topo = topo.getProximo();
        tamanho--;
        return valor;
    }

    /**
     * Consulta o topo sem remover. Custo O(1).
     *
     * @return elemento do topo
     * @throws EstruturaVaziaException se a pilha estiver vazia
     */
    public T topo() {
        if (estaVazia()) throw new EstruturaVaziaException("Pilha");
        return topo.getValor();
    }

    /** Busca um valor na pilha. Custo O(n). @param valor procurado @return true se existe */
    public boolean buscar(T valor) {
        for (No<T> n = topo; n != null; n = n.getProximo()) {
            if (n.getValor().equals(valor)) return true;
        }
        return false;
    }

    /** @return true se vazia */
    public boolean estaVazia() { return tamanho == 0; }

    /** @return quantidade de elementos */
    public int tamanho() { return tamanho; }
}
