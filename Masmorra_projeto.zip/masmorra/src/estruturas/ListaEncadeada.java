package estruturas;

import excecoes.EstruturaVaziaException;
import excecoes.IndiceInvalidoException;
import java.util.Iterator;

/**
 * Lista encadeada simples implementada do zero.
 * No jogo ela guarda a mochila do jogador e também serve para devolver
 * os resultados dos percursos da árvore.
 *
 * @param <T> tipo dos elementos
 */
public class ListaEncadeada<T> implements Iterable<T> {
    private No<T> inicio;
    private No<T> fim;
    private int tamanho;

    /** Insere no fim da lista. Custo O(1). @param valor elemento a inserir */
    public void inserir(T valor) {
        No<T> novo = new No<>(valor);
        if (inicio == null) {
            inicio = novo;
        } else {
            fim.setProximo(novo);
        }
        fim = novo;
        tamanho++;
    }

    /**
     * Remove a primeira ocorrência do valor. Custo O(n).
     *
     * @param valor elemento a remover
     * @return true se removeu, false se não encontrou
     * @throws EstruturaVaziaException se a lista estiver vazia
     */
    public boolean remover(T valor) {
        if (estaVazia()) throw new EstruturaVaziaException("ListaEncadeada");
        No<T> anterior = null;
        No<T> atual = inicio;
        while (atual != null) {
            if (atual.getValor().equals(valor)) {
                if (anterior == null) inicio = atual.getProximo();
                else anterior.setProximo(atual.getProximo());
                if (atual == fim) fim = anterior;
                tamanho--;
                return true;
            }
            anterior = atual;
            atual = atual.getProximo();
        }
        return false;
    }

    /** Busca um valor. Custo O(n). @param valor elemento procurado @return true se existe */
    public boolean buscar(T valor) {
        for (T v : this) {
            if (v.equals(valor)) return true;
        }
        return false;
    }

    /**
     * Obtém o elemento de uma posição. Custo O(n).
     *
     * @param indice posição (0 a tamanho-1)
     * @return elemento da posição
     * @throws IndiceInvalidoException se o índice estiver fora dos limites
     */
    public T obter(int indice) {
        if (indice < 0 || indice >= tamanho) throw new IndiceInvalidoException(indice, tamanho);
        No<T> atual = inicio;
        for (int i = 0; i < indice; i++) atual = atual.getProximo();
        return atual.getValor();
    }

    /** @return true se não há elementos */
    public boolean estaVazia() { return tamanho == 0; }

    /** @return quantidade de elementos */
    public int tamanho() { return tamanho; }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            private No<T> atual = inicio;
            public boolean hasNext() { return atual != null; }
            public T next() {
                T v = atual.getValor();
                atual = atual.getProximo();
                return v;
            }
        };
    }
}
