package estruturas;

/**
 * Árvore binária de busca (ABB). No jogo indexa o ranking de jogadores por nome.
 * Sem balanceamento: caso médio O(log n), pior caso O(n) (dados já ordenados).
 *
 * @param <T> tipo comparável dos elementos
 */
public class ArvoreBinariaBusca<T extends Comparable<T>> {

    private static class NoArvore<T> {
        T valor;
        NoArvore<T> esquerda, direita;
        NoArvore(T valor) { this.valor = valor; }
    }

    private NoArvore<T> raiz;
    private int tamanho;

    /**
     * Insere um valor. Ignora duplicados.
     *
     * @param valor elemento a inserir
     * @return true se inseriu, false se já existia um igual
     */
    public boolean inserir(T valor) {
        if (raiz == null) {
            raiz = new NoArvore<>(valor);
            tamanho++;
            return true;
        }
        NoArvore<T> atual = raiz;
        while (true) {
            int cmp = valor.compareTo(atual.valor);
            if (cmp == 0) return false;
            if (cmp < 0) {
                if (atual.esquerda == null) { atual.esquerda = new NoArvore<>(valor); break; }
                atual = atual.esquerda;
            } else {
                if (atual.direita == null) { atual.direita = new NoArvore<>(valor); break; }
                atual = atual.direita;
            }
        }
        tamanho++;
        return true;
    }

    /**
     * Busca um valor.
     *
     * @param chave valor com a chave procurada
     * @return o elemento guardado ou null se não existir
     */
    public T buscar(T chave) {
        NoArvore<T> atual = raiz;
        while (atual != null) {
            int cmp = chave.compareTo(atual.valor);
            if (cmp == 0) return atual.valor;
            atual = cmp < 0 ? atual.esquerda : atual.direita;
        }
        return null;
    }

    /** @return true se a árvore está vazia */
    public boolean estaVazia() { return raiz == null; }

    /** @return quantidade de elementos */
    public int tamanho() { return tamanho; }

    /** @return altura da árvore (árvore vazia = 0) */
    public int altura() { return altura(raiz); }

    private int altura(NoArvore<T> no) {
        if (no == null) return 0;
        return 1 + Math.max(altura(no.esquerda), altura(no.direita));
    }

    /** Percurso pré-ordem (raiz, esquerda, direita). @return elementos na ordem visitada */
    public ListaEncadeada<T> preOrdem() {
        ListaEncadeada<T> lista = new ListaEncadeada<>();
        preOrdem(raiz, lista);
        return lista;
    }

    private void preOrdem(NoArvore<T> no, ListaEncadeada<T> lista) {
        if (no == null) return;
        lista.inserir(no.valor);
        preOrdem(no.esquerda, lista);
        preOrdem(no.direita, lista);
    }

    /** Percurso em-ordem (esquerda, raiz, direita): sai ordenado. @return elementos na ordem visitada */
    public ListaEncadeada<T> emOrdem() {
        ListaEncadeada<T> lista = new ListaEncadeada<>();
        emOrdem(raiz, lista);
        return lista;
    }

    private void emOrdem(NoArvore<T> no, ListaEncadeada<T> lista) {
        if (no == null) return;
        emOrdem(no.esquerda, lista);
        lista.inserir(no.valor);
        emOrdem(no.direita, lista);
    }

    /** Percurso pós-ordem (esquerda, direita, raiz). @return elementos na ordem visitada */
    public ListaEncadeada<T> posOrdem() {
        ListaEncadeada<T> lista = new ListaEncadeada<>();
        posOrdem(raiz, lista);
        return lista;
    }

    private void posOrdem(NoArvore<T> no, ListaEncadeada<T> lista) {
        if (no == null) return;
        posOrdem(no.esquerda, lista);
        posOrdem(no.direita, lista);
        lista.inserir(no.valor);
    }
}
