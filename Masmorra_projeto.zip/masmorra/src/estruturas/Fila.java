package estruturas;

import excecoes.EstruturaVaziaException;

/**
 * Fila (FIFO) encadeada com ponteiros para início e fim.
 * No jogo guarda os monstros na ordem em que vão aparecer.
 *
 * @param <T> tipo dos elementos
 */
public class Fila<T> {
    private No<T> inicio;
    private No<T> fim;
    private int tamanho;

    /** Entra no fim da fila. Custo O(1). @param valor elemento a enfileirar */
    public void enfileirar(T valor) {
        No<T> novo = new No<>(valor);
        if (fim == null) inicio = novo;
        else fim.setProximo(novo);
        fim = novo;
        tamanho++;
    }

    /**
     * Sai do início da fila. Custo O(1).
     *
     * @return elemento removido
     * @throws EstruturaVaziaException se a fila estiver vazia
     */
    public T desenfileirar() {
        if (estaVazia()) throw new EstruturaVaziaException("Fila");
        T valor = inicio.getValor();
        inicio = inicio.getProximo();
        if (inicio == null) fim = null;
        tamanho--;
        return valor;
    }

    /**
     * Consulta o primeiro sem remover. Custo O(1).
     *
     * @return primeiro elemento
     * @throws EstruturaVaziaException se a fila estiver vazia
     */
    public T primeiro() {
        if (estaVazia()) throw new EstruturaVaziaException("Fila");
        return inicio.getValor();
    }

    /** Busca um valor na fila. Custo O(n). @param valor procurado @return true se existe */
    public boolean buscar(T valor) {
        for (No<T> n = inicio; n != null; n = n.getProximo()) {
            if (n.getValor().equals(valor)) return true;
        }
        return false;
    }

    /** @return true se vazia */
    public boolean estaVazia() { return tamanho == 0; }

    /** @return quantidade de elementos */
    public int tamanho() { return tamanho; }
}
